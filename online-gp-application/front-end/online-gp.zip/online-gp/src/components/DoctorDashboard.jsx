// DoctorDashboard.jsx
import React from 'react';

const DoctorDashboard = () => {
  return (
    <div>
      <h1>Welcome, Doctor!</h1>
      {/* Dashboard content goes here */}
    </div>
  );
};

export default DoctorDashboard;
