package com.online.gpapplication.Service;

import org.springframework.stereotype.Service;

@Service
public class OtpEntryService {

}
