package com.online.gpapplication.Model;

public class TechnicalRequestDTO {

}
